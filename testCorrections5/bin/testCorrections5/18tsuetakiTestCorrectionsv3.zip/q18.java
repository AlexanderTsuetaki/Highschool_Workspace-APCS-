package testCorrections5;

import org.omg.CORBA.SystemException;

public class q18 {
	public static void main(String[] args){
		System.out.println(14*14);//selection sort
		System.out.println(14*(Math.log(14)/Math.log(2)));//merge sort thus must be greater than 37 and thus E is the only correct answer.
		System.out.println(14*14);//insertion sort
		System.out.println(14*14);//quick sort
	}
}

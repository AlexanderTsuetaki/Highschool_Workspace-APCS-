package testCorrections5;

public class q24a {

}
